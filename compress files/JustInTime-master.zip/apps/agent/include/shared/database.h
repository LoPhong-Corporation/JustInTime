//
// Created by LoPhongCorporation on 6/24/2026.
//

#ifndef DATABASE_H
#define DATABASE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sync.h"
#include "activity.h"

int db_init(void);

int db_insert_activity(
    const ActivityRecord* record
);

void db_print_unsynced(void);

/*
 * In báo cáo tổng thời gian sử dụng mỗi app trong ngày
 * hôm nay ra console (gộp các record dù bị chia nhỏ theo
 * từng lần đổi window title).
 */
void db_print_daily_summary(void);

/*
 * Build nội dung báo cáo tổng hợp theo app hôm nay vào
 * buffer, dùng để hiển thị trong MessageBox của tray.
 * Trả về 1 nếu có dữ liệu, 0 nếu chưa có.
 */
int db_build_daily_summary_text(
    wchar_t* out,
    int out_size
);

/*
 * 1 dòng trong bảng tổng hợp app hôm nay (xem
 * db_get_today_app_summary) - dùng cho UI có thể hiển thị icon
 * riêng từng app (ControlPanelWindow::buildOverviewPage), thay vì
 * chỉ có 1 khối text phẳng như db_build_daily_summary_text().
 */
typedef struct {
    wchar_t process_name[512];
    long long total_seconds;
} DailyAppSummaryEntry;

#define DAILY_APP_SUMMARY_MAX 15

/*
 * Giống db_build_daily_summary_text() nhưng trả về dữ liệu có cấu
 * trúc (mảng process_name + tổng giây) thay vì text đã build sẵn -
 * cùng 1 truy vấn SQL, chỉ khác điểm ra. Trả về số dòng lấy được
 * (0 nếu chưa có dữ liệu hôm nay).
 */
int db_get_today_app_summary(
    DailyAppSummaryEntry* out,
    int max_entries
);

/*
 * Tổng số giây đã dùng HÔM NAY cho 1 process cụ thể (tính từ
 * 00:00 giờ địa phương) - dùng để đối chiếu với app_limits khi
 * kiểm tra giới hạn thời gian do phụ huynh đặt (xem
 * activity_check_limits() trong core/activity.c).
 */
long db_get_today_seconds(
    const wchar_t* process_name
);

void db_close(void);

int db_get_unsynced_records(
    SyncRecord* records,
    int max_records
);

int db_mark_synced(int id);

/*
 * Đánh dấu NHIỀU record đã sync bằng 1 câu UPDATE duy nhất (atomic, 1 lần
 * ghi đĩa thay vì count lần). Trả về 1 nếu thành công.
 */
int db_mark_synced_batch(const int* ids, int count);

/*
 * Tổng số dòng đã thay đổi (insert/update/delete) trên kết nối này từ lúc
 * mở DB. backup.cpp dùng để biết dữ liệu có đổi kể từ lần backup trước
 * hay không. Trả về 0 nếu DB chưa mở.
 */
long long db_change_counter(void);

/*
 * Đánh dấu 1 record gửi thất bại: tăng retry_count và
 * tính lại thời điểm thử lại tiếp theo (exponential backoff).
 */
int db_mark_sync_failed(int id);

int db_count_unsynced(void);

int db_delete_old_records(int days);

int db_mark_record_synced(
    int id
);

/*
 * Xuất toàn bộ dữ liệu ra file JSON (backup cục bộ). filepath là UTF-8.
 * Ghi ra "<filepath>.tmp" rồi đổi tên nên không bao giờ để lại file dở dang.
 * Trả về 1 nếu thành công, 0 nếu thất bại.
 */
int db_export_json(
    const char* filepath
);


#ifdef __cplusplus
}
#endif

#endif